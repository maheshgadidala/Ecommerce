//package com.JavaEcommerce.Ecommerce.config;
//
//import org.apache.kafka.clients.admin.NewTopic;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class KafkaTopic {
//
//    @Bean
//
//    public NewTopic productTopic(){
//
//        return new NewTopic("product-topic", 5, (short) 1);
//    }
//
//    @Bean
//    public NewTopic productJsonTopic(){
//
//        return new NewTopic("productJson-topic", 5, (short) 1);
//    }
//
//}
